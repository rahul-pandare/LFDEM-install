var class_linear_clock =
[
    [ "LinearClock", "class_linear_clock.html#a716bfc2b617d29a7b5a77dde65f38a48", null ],
    [ "tick", "class_linear_clock.html#aad9ff6b5f9b00e2cd39ba7bb6ef74c79", null ]
];