var class_time_keeper =
[
    [ "addClock", "class_time_keeper.html#a6e077f4cff82e31659e99880090df07c", null ],
    [ "addClock", "class_time_keeper.html#a07ec0736644fa0e85be5a75d1fe450cd", null ],
    [ "getElapsedClocks", "class_time_keeper.html#a20f18ff43bc266301941358bd28a4e9c", null ],
    [ "nextStrain", "class_time_keeper.html#a2c338790ce3e10bbf3e170afaa74de43", null ],
    [ "nextTime", "class_time_keeper.html#a7bdbc2ff02919839211142165a82ac7e", null ],
    [ "clocks", "class_time_keeper.html#addce4bc6f4451922948e51a4c1f86d3b", null ]
];