var class_log_clock =
[
    [ "LogClock", "class_log_clock.html#afbf36c7751766a1f8dd16bb4dd4f4b5a", null ],
    [ "tick", "class_log_clock.html#aa4377f1f76d07206096c89180d9ef2a6", null ],
    [ "first_non_zero", "class_log_clock.html#ab457f372b8ad2c78566c35ead4805e3b", null ]
];