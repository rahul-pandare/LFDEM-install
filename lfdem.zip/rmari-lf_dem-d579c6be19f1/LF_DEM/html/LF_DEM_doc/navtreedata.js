var NAVTREE =
[
  [ "Documentation for LF_DEM", "index.html", [
    [ "Bibliography", "citelist.html", null ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"class_interaction.html#a0ae4120084cf078a20d18e1fd0eadd5e",
"class_simulation.html#a7beda171dd6deea7f758f016664a2826",
"class_system.html#a6893e8bed1008312c6167861da04e146",
"struct_force_component.html#a5dfae3aadeb7931d964055453c72df5a"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';