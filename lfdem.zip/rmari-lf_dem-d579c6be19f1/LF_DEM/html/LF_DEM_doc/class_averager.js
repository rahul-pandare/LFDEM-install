var class_averager =
[
    [ "Averager", "class_averager.html#a7042ac6b23247e9cf2784e46117f9bbe", null ],
    [ "~Averager", "class_averager.html#a96e22f4b24dfd64d7f982267a8879bc7", null ],
    [ "get", "class_averager.html#aa9d27fac0fd3640ca81dadb365a8ab98", null ],
    [ "setRelaxationTime", "class_averager.html#a0c4a0e3a67a33d608f871cb6630cdbd1", null ],
    [ "update", "class_averager.html#ae5f0d55419b26b218cb16c7ce1c3dbf3", null ],
    [ "previous_kernel_norm", "class_averager.html#a5745a092bc9bce45d1e61b3f2882c3e1", null ],
    [ "previous_time", "class_averager.html#addede029f95e9bf33de19017a4112837", null ],
    [ "relaxation_time", "class_averager.html#a4183e4a4d11a07623bcdca6e0ae99b83", null ],
    [ "x_avg", "class_averager.html#a3c23463e8c8f7721c5df67ae87939d0d", null ]
];