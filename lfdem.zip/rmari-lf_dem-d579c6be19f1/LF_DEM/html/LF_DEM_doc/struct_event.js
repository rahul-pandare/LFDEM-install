var struct_event =
[
    [ "type", "struct_event.html#ab534424ccc9aeb0bedd8880af34befbb", null ]
];