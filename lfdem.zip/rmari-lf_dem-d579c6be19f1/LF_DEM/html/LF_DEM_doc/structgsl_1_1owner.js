var structgsl_1_1owner =
[
    [ "type", "structgsl_1_1owner.html#ad5f904920decb4282bea78f0662d5616", null ]
];