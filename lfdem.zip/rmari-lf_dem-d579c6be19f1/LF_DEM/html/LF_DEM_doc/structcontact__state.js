var structcontact__state =
[
    [ "disp_rolling", "structcontact__state.html#a72fc6cb5d799f43f198725b1c33db949", null ],
    [ "disp_tan", "structcontact__state.html#a778a5cb929720418fc3a6568400d5af8", null ],
    [ "p0", "structcontact__state.html#a8099c3a877293c97091250f66b1fe8a8", null ],
    [ "p1", "structcontact__state.html#a9d5c444c1a5529962c875f2d3113b7f6", null ]
];