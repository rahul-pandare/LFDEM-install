var struct_value =
[
    [ "Value", "struct_value.html#aa1e674fa23180ce75c8c67c6bd56d389", null ],
    [ "val", "struct_value.html#af94be666d38f2873180b75a51aa83355", null ]
];