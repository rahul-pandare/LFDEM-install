var structcompare__interaction =
[
    [ "operator()", "structcompare__interaction.html#aececf568d83999c5d00458d66f3b22ab", null ]
];