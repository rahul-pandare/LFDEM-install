var struct_dimensional_value =
[
    [ "type", "struct_dimensional_value.html#a3f2734327a91947f72ea155d7bf3d302", null ],
    [ "unit", "struct_dimensional_value.html#a3ca2a96d3e96e0d336fa3c03c1873b57", null ],
    [ "value", "struct_dimensional_value.html#ac8cc8513df1f3204c318fca85e8ec9d1", null ]
];