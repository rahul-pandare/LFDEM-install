var class_clock =
[
    [ "Clock", "class_clock.html#a656df0b673350f7eae3716a07e14ce0f", null ],
    [ "is_strain", "class_clock.html#ac5077fcd06e2b945f7a48b1f8c15fd93", null ],
    [ "nextTime", "class_clock.html#af1841fd8c0e14868f07189dbff6bd485", null ],
    [ "tick", "class_clock.html#a47d82a3b53af4fc36a3302bab655a9fe", null ],
    [ "_strain", "class_clock.html#ae3c455293ce05e10f1892b921a85d56e", null ],
    [ "next_time", "class_clock.html#a88886726bb27b7eb8b54d6ae98459862", null ],
    [ "time_step", "class_clock.html#abaa78abbc24eea99c5c7c9d836a4b1ce", null ]
];