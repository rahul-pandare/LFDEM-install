var struct_input_value =
[
    [ "type", "struct_input_value.html#a556f4bc42882420cc7fbe8e3407bd365", null ],
    [ "unit", "struct_input_value.html#a41bae2093ee8e3dbb8cf3c1febadd254", null ],
    [ "value", "struct_input_value.html#a6851f08e36f9543dc7d433927c52df25", null ]
];